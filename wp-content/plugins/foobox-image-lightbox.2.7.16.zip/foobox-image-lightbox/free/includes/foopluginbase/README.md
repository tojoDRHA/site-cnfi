Foo_Plugin_Base
===============

A base class for WordPress plugins. Get up and running quickly with this opinionated, convention based, plugin framework
