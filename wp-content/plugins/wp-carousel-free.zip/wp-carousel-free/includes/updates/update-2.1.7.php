<?php
/**
 * Update version.
 */
update_option( 'wp_carousel_free_version', '2.1.7' );
update_option( 'wp_carousel_free_db_version', '2.1.7' );
