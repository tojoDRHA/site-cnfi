<?php


namespace Nextend\Framework\Request\Parser;


abstract class AbstractRequestParser {

    public abstract function parseData($data);

}