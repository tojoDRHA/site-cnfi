<?php
/*
 * Q : Where are the built-in gallery templates?
 * A : They can be found in "wp-content/foogallery/extensions/default-templates"
 *
 * Q : Why are they not in "wp-content/foogallery/templates"?
 * A : We wanted the built-in templates to be packaged in a FooGallery extension, so that you can disable them if you wanted to.
*/
